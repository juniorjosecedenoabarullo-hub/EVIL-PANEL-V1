EVIL PANEL V1 — Proyecto Android inicial

Este proyecto crea una app independiente de estilo gaming, con interfaz negra y morada.
Incluye Inicio, Ajustes (un control de referencia personal) e Información.

No modifica Free Fire, no inyecta scripts, no automatiza acciones y no accede a cuentas.

Cómo generar el APK:
1. Instala Android Studio en un ordenador.
2. Abre la carpeta EVIL_PANEL_V1 en Android Studio.
3. Espera a que Gradle sincronice y descargue las dependencias.
4. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio generará el APK en app/build/outputs/apk/debug/.

Requisitos: Android Studio reciente y conexión a internet durante la primera sincronización.
