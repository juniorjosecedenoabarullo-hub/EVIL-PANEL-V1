package com.evilpanel.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF100D1C)
private val Card = Color(0xFF241A36)
private val Purple = Color(0xFFC5A2FF)
private val Muted = Color(0xFFB9A9CC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EvilPanelApp() }
    }
}

@Composable
fun EvilPanelApp() {
    var selected by remember { mutableStateOf("Inicio") }
    var sensitivity by remember { mutableFloatStateOf(75f) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Card, primary = Purple,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Bg).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("EVIL PANEL", color = Purple, fontSize = 27.sp, fontWeight = FontWeight.Black)
                    Text("VERSION 1.0  •  FREE FIRE COMPANION", color = Muted, fontSize = 10.sp)
                }
                Surface(color = Color(0xFF193B2A), shape = RoundedCornerShape(50)) {
                    Text("READY", color = Color(0xFF80E6A8), modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp)
                }
            }
            Text("Herramientas de jugador", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Inicio", "Ajustes", "Info").forEach { tab ->
                    FilterChip(selected = selected == tab, onClick = { selected = tab }, label = { Text(tab) })
                }
            }
            when (selected) {
                "Inicio" -> {
                    PanelCard("ESTADÍSTICAS") {
                        Text("Tu espacio para organizar tus datos de juego.", color = Muted)
                        Text("Perfil: Jugador", color = Purple, fontWeight = FontWeight.Bold)
                    }
                    PanelCard("ACCESOS RÁPIDOS") {
                        Text("• Consejos de precisión", color = Color.White)
                        Text("• Guía de controles", color = Color.White)
                        Text("• Registro de partidas", color = Color.White)
                    }
                }
                "Ajustes" -> PanelCard("SENSIBILIDAD PERSONAL") {
                    Text("Valor de referencia: ${sensitivity.toInt()}", color = Purple, fontWeight = FontWeight.Bold)
                    Slider(value = sensitivity, onValueChange = { sensitivity = it }, valueRange = 0f..100f)
                    Text("Ajusta este valor como nota personal. No cambia la configuración del juego.", color = Muted, fontSize = 12.sp)
                }
                else -> PanelCard("ACERCA DE") {
                    Text("EVIL PANEL V1 es una app independiente de organización y consejos.", color = Color.White)
                    Text("No modifica Free Fire, no inyecta código y no accede a tu cuenta.", color = Muted)
                }
            }
            Spacer(Modifier.weight(1f))
            Text("DESIGNED BY EVIL  •  SAFE COMPANION APP", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
fun PanelCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            content()
        }
    }
}
